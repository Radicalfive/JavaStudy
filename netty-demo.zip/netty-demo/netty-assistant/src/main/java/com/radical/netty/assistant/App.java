package com.radical.netty.assistant;

/**
 * @description:
 * @author: mqxu
 * @date: 2021/10/30
 */
public class App {
}
