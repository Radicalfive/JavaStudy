public class Resource {
    public static final ImageIcon logo = new ImageIcon(Resource.class.getResource("/resource/logo.png"));
}