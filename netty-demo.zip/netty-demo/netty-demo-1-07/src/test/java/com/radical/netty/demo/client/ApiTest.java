package com.radical.netty.demo.client;

public class ApiTest {
}
