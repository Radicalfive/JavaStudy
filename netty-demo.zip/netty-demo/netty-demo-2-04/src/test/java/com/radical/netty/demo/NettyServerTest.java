package com.radical.netty.demo;

import com.radical.netty.demo.server.NettyServer;

/**
 * @description: NettyServerTest
 * @author: radical
 * @date: 2021-11-02
 **/
public class NettyServerTest {

    public static void main(String[] args) {
        System.out.println("永远二十赶朝暮，永远年轻");
        new NettyServer().bing(7397);
    }
}
